package AreaCircle;
import java.util.*;


public class Circle {
	
	static double CircleA(int r){
		
		return (3.14*r*r);
		 }
    public static void main(String args[]) {
	System.out.println("Enter the radius");
	Scanner sc =new Scanner(System.in);
    int r=sc.nextInt();
	System.out.println("Area:"+Circle.CircleA(r));
}

	                }
