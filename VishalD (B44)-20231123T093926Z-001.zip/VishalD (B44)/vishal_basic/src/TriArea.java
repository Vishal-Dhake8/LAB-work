
public class TriArea {

}
