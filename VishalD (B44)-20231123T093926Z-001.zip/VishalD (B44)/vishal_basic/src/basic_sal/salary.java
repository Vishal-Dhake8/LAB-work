package basic_sal;

import java.util.*;

public class salary 
{
	
	public static void main(String args[])
	{
		int da,hra,totalsal,basicsal;
	    Scanner sc=new Scanner(System.in);
		System.out.println("Enter your basic salary:");
		basicsal=sc.nextInt();
		
		da=(10*basicsal)/100;
		hra=(20*basicsal)/100;
		
		totalsal=da+hra+basicsal;
		System.out.println("total salary is:"+totalsal);
	}

}
