package String;

public class Stringln {
   public static void main(String[]args)
   {
	    int l;
	    String str="Vishal is the greatest person to ever live on the face of earth";
	    l=str.length();
	    System.out.println("The length is "+l);
   
   }
}
