package AreaTriangle;
import java.util.Scanner;
public class TriArea {

	
	static double TriA(int l,int b){
		
		return (l*b);
		 }
    public static void main(String args[]) {
	System.out.println("Enter length & bredth");
	Scanner sc =new Scanner(System.in);
    int l=sc.nextInt();
    int b=sc.nextInt();
	System.out.println("Area:"+TriArea.TriA());
}


}
