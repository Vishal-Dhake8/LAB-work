package stringoperation;
import java .util.*;
public class String {
public static void main(String args[]) {
	
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the String");
	String v=sc.nextLine();
	System.out.println("length is:"+v.length());

	
}
}
