package AreaT;
import java.util.Scanner;
public class TriA {
			static double TriAr(int l,int b){
			
			return (l*b);
			 }
	    public static void main(String args[]) {
		System.out.println("Enter length & bredth");
 		Scanner sc =new Scanner(System.in);
	    int l=sc.nextInt();
	    int b=sc.nextInt();
		System.out.println("Area:"+TriA.TriAr(l, b));
	}


	}


