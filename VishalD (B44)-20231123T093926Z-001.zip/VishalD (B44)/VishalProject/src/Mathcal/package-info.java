package Mathcal;
import java.util.Scanner;
public class MathOps{

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
	    System.out.println("Enter the first no: ");
		int num1=sc.nextInt();
		
		System.out.println("Enter the second no: ");
		double num2=sc.nextDouble();
		
		System.out.println("Enter the third no: ");
		float num3=sc.nextFloat();
		
		System.out.println("the maximum number is : "+Math.max(num1, num2));
		
		System.out.println("the minimum number is : "+Math.min(num1, num2));
		
		System.out.println("the round of number is : "+Math.round(num3));
		
		System.out.println("the absolute of number is "+Math.abs(num2));
		
		System.out.println("the log of number is :    "+Math.log(num3));
		
	    

	}

}